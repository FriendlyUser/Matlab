function f = grad52(x)
x1 = x(1);
x2 = x(2);
f1 = 2*x1+4;
f2 = 4*x2+4;
f = [f1;f2];