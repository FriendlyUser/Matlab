function f = funcNet1(x)
x1= x(1);
x2 =x(2);
f = 2*x1^2+10*x2^2;