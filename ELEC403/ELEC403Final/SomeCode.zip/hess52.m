function f = hess52(x)
x1 = x(1);
x2 = x(2);
f= [2 0; 0 4;];