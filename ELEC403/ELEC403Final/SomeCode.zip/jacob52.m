function j = jacob52(x)
x1 = x(1);
x2 = x(2);
j = [1, 0; 0, sqrt(2)];