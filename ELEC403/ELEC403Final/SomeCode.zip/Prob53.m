function f = Prob53(x)
x1 = x(1);
x2 = x(2);
f = x1^2+x2^2-0.2*x1*x2-2.2*x1+2.2*x2+2.2;