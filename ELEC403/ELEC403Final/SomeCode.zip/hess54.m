function z = hess54(x)
x1 = x(1);
x2 = x(2);
z= [10 -9; ...
    -9 163/20];