function z = func54(x)
x1 = x(1); 
x2 = x(2); 
z = 5*x1^2-9*x1*x2+4.075*x2^2+x1;