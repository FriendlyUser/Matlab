function f = jacobNet1(x)
x1= x(1);
x2 =x(2);
f = [ sqrt(2) 0; 0 sqrt(10)];