function f = func52(x)
x1 = x(1);
x2 = x(2);
f = x1^2+2*x2^2+4*x1+4*x2;