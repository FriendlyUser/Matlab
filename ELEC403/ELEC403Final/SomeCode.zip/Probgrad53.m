function g = Probgrad53(x)
x1 = x(1);
x2 = x(2);
g1 = 2*x1 - x2/5 - 11/5;
g2 = 2*x2 - x1/5 + 11/5;
g = [g1; g2];